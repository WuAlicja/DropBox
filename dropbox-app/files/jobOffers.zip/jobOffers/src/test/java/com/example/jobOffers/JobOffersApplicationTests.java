package com.example.jobOffers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobOffersApplicationTests {

	@Test
	void contextLoads() {
	}

}
